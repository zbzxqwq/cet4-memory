package com.cet4.memo;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.speech.tts.TextToSpeech;
import android.util.Base64;
import android.view.KeyEvent;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.Locale;

/**
 * 四级记忆 · 安卓版
 * 把网页版装进 WebView 里，并补上浏览器做不到的三件事：
 *   1. 导出 Word / 学习记录 —— 直接写进手机的「下载 / 四级记忆」文件夹
 *   2. 单词发音 —— 调用安卓系统的语音朗读
 *   3. 选择文件 —— 支持「导入学习记录」
 */
public class MainActivity extends Activity {

    private WebView web;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private boolean ttsInitDone = false;
    private int ttsInitStatus = TextToSpeech.ERROR;
    private ValueCallback<Uri[]> fileCallback;
    private static final int REQ_FILE = 1001;
    private static final int REQ_PERM = 2001;
    private String pendingImport = null;    // 蓝牙发来的学习记录，等页面加载好再导入
    private boolean pageReady = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 语音朗读（注意：不能在 onInit 里碰 tts 变量，那时候它可能还没赋值）
        tts = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                ttsInitStatus = status;
                ttsInitDone = true;
            }
        });

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);          // localStorage，学习记录靠它
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        try { WebView.setWebContentsDebuggingEnabled(false); } catch (Throwable ignored) {}

        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView v, String url) {
                pageReady = true;
                flushPendingImport();
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb,
                                             FileChooserParams params) {
                fileCallback = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                try {
                    startActivityForResult(Intent.createChooser(i, "选择文件"), REQ_FILE);
                    return true;
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
            }
        });

        // 给网页用的桥：window.AndroidHost
        web.addJavascriptInterface(new Bridge(), "AndroidHost");
        web.loadUrl("file:///android_asset/index.html");

        setContentView(web);
        askStoragePermission();
        handleImportIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleImportIntent(intent);
    }

    /* 蓝牙 / 微信收到 .json 之后点「用四级记忆打开」，就会走到这里 */
    private void handleImportIntent(Intent intent) {
        if (intent == null) return;
        Uri uri = intent.getData();
        if (uri == null && Intent.ACTION_SEND.equals(intent.getAction())) {
            Object extra = intent.getParcelableExtra(Intent.EXTRA_STREAM);
            if (extra instanceof Uri) uri = (Uri) extra;
        }
        if (uri == null) return;
        try {
            InputStream is = getContentResolver().openInputStream(uri);
            if (is == null) return;
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = is.read(buf)) > 0) bos.write(buf, 0, n);
            is.close();
            pendingImport = new String(bos.toByteArray(), Charset.forName("UTF-8"));
            flushPendingImport();
        } catch (Throwable t) {
            Toast.makeText(this, "这个文件读不出来", Toast.LENGTH_SHORT).show();
        }
    }

    private void flushPendingImport() {
        if (pendingImport == null || !pageReady || web == null) return;
        final String text = pendingImport;
        pendingImport = null;
        web.post(new Runnable() {
            @Override
            public void run() {
                try {
                    String js = "window.__importText && window.__importText(" +
                                JSONObject.quote(text) + ")";
                    web.evaluateJavascript(js, null);
                } catch (Throwable ignored) {}
            }
        });
    }

    /* ---------------- 给网页调用的接口 ---------------- */
    private class Bridge {

        @JavascriptInterface
        public String platform() {
            return "android";
        }

        /** 把文件直接保存到 下载/四级记忆/ 里 */
        @JavascriptInterface
        public void saveDoc(final String filename, final String content) {
            final boolean ok = writeToDownloads(filename, content);
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(MainActivity.this,
                            ok ? ("已保存到「下载/四级记忆/」：" + filename)
                               : "保存失败，请检查存储权限",
                            Toast.LENGTH_LONG).show();
                }
            });
        }

        /** 保存 .docx 这类二进制文件（网页把字节转成 base64 传过来） */
        @JavascriptInterface
        public void saveBinary(final String filename, final String base64) {
            boolean ok = false;
            try {
                ok = writeBytesToDownloads(filename, Base64.decode(base64, Base64.DEFAULT));
            } catch (Throwable t) {
                ok = false;
            }
            final boolean done = ok;
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(MainActivity.this,
                            done ? ("已保存到「下载/四级记忆/」：" + filename)
                                 : "保存失败，请检查存储权限",
                            Toast.LENGTH_LONG).show();
                }
            });
        }

        /** 用系统语音读单词 */
        @JavascriptInterface
        public boolean speak(final String text) {
            if (text == null) return false;
            if (!ttsReady) {
                // 可能初始化还没完成，或者刚才语言没设上，这里再试一次
                prepareTts();
                if (!ttsReady) return false;
            }
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        tts.stop();
                        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "cet4");
                    } catch (Throwable ignored) {}
                }
            });
            return true;
        }

        @JavascriptInterface
        public void toast(final String msg) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    /* 把语言、语速设好。TTS 是异步初始化的，所以可能要多试几次 */
    private void prepareTts() {
        if (tts == null) return;
        if (!ttsInitDone) return;                 // 还没初始化完，等下次
        if (ttsInitStatus != TextToSpeech.SUCCESS) return;
        try {
            int r = tts.setLanguage(Locale.US);
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                r = tts.setLanguage(Locale.ENGLISH);
            }
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                ttsReady = false;
                return;
            }
            tts.setSpeechRate(0.85f);
            tts.setPitch(1.0f);
            ttsReady = true;
        } catch (Throwable t) {
            ttsReady = false;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        prepareTts();
    }

    /* ---------------- 写文件 ---------------- */
    private boolean writeToDownloads(String filename, String content) {
        return writeBytesToDownloads(filename, content.getBytes(Charset.forName("UTF-8")));
    }

    private boolean writeBytesToDownloads(String filename, byte[] bytes) {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                // Android 10 以上：用 MediaStore，不需要任何权限
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.Downloads.DISPLAY_NAME, filename);
                cv.put(MediaStore.Downloads.MIME_TYPE, mimeOf(filename));
                cv.put(MediaStore.Downloads.RELATIVE_PATH,
                        Environment.DIRECTORY_DOWNLOADS + "/四级记忆");
                Uri uri = getContentResolver()
                        .insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                if (uri == null) return false;
                OutputStream os = getContentResolver().openOutputStream(uri);
                if (os == null) return false;
                os.write(bytes);
                os.flush();
                os.close();
                return true;
            }

            // Android 9 及以下：直接写到公共下载目录
            File dir = new File(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                    "四级记忆");
            if (!dir.exists() && !dir.mkdirs()) return false;
            FileOutputStream fos = new FileOutputStream(new File(dir, filename));
            fos.write(bytes);
            fos.flush();
            fos.close();
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    private static String mimeOf(String name) {
        String n = name.toLowerCase(Locale.US);
        if (n.endsWith(".doc")) return "application/msword";
        if (n.endsWith(".json")) return "application/json";
        if (n.endsWith(".txt")) return "text/plain";
        return "application/octet-stream";
    }

    /* ---------------- 权限 ---------------- */
    private void askStoragePermission() {
        if (Build.VERSION.SDK_INT >= 23 && Build.VERSION.SDK_INT <= 28) {
            if (checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{
                        android.Manifest.permission.WRITE_EXTERNAL_STORAGE,
                        android.Manifest.permission.READ_EXTERNAL_STORAGE
                }, REQ_PERM);
            }
        }
    }

    /* ---------------- 选文件回调 ---------------- */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_FILE) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                results = new Uri[]{ data.getData() };
            }
            if (fileCallback != null) {
                fileCallback.onReceiveValue(results);
                fileCallback = null;
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && web != null && web.canGoBack()) {
            web.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onDestroy() {
        if (tts != null) {
            try { tts.stop(); tts.shutdown(); } catch (Throwable ignored) {}
            tts = null;
        }
        super.onDestroy();
    }
}
