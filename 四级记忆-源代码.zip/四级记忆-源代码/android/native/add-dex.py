#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""把 classes.dex 塞进 aapt2 生成的 base.apk，输出 unsigned.apk。"""

import sys
import zipfile


def main():
    if len(sys.argv) != 4:
        print("用法: add-dex.py base.apk classes.dex out.apk")
        return 1
    base, dex, out = sys.argv[1], sys.argv[2], sys.argv[3]

    with zipfile.ZipFile(base, "r") as zin, \
            zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            zout.writestr(item, zin.read(item.filename))
        zout.write(dex, "classes.dex")

    print("classes.dex 已写入 %s" % out)
    return 0


if __name__ == "__main__":
    sys.exit(main())
