﻿# ============================================================
#  CET4 Memo - Android APK builder (no Gradle / no Android Studio)
#
#  Usage:  .\build-apk.ps1
#  Output: ..\..\dist\<app>.apk
#
#  NOTE: all messages are ASCII on purpose (PowerShell 5.1 reads
#  .ps1 as ANSI unless it has a BOM, which breaks non-ASCII text).
#  NOTE: aapt2 cannot handle non-ASCII paths, so everything is
#  staged into an ASCII temp folder first.
# ============================================================

$ErrorActionPreference = 'Stop'

# ---------------- paths ----------------
$here    = Split-Path -Parent $MyInvocation.MyCommand.Path
$appRoot = (Resolve-Path (Join-Path $here '..\..')).Path
$outDir  = Join-Path (Split-Path -Parent $appRoot) 'dist'

$sdkRoot    = 'D:\android-sdk'
$jdk        = 'C:\Users\20682\AppData\Roaming\.minecraft\runtime\java-runtime-gamma-snapshot'
$bt         = Join-Path $sdkRoot 'build-tools\34.0.0'
$androidJar = Join-Path $sdkRoot 'platforms\android-34\android.jar'

$aapt2     = Join-Path $bt 'aapt2.exe'
$zipalign  = Join-Path $bt 'zipalign.exe'
$apksigner = Join-Path $bt 'apksigner.bat'
$d8        = Join-Path $bt 'd8.bat'
$javac     = Join-Path $jdk 'bin\javac.exe'
$keytool   = Join-Path $jdk 'bin\keytool.exe'

foreach ($p in @($aapt2, $zipalign, $apksigner, $d8, $javac, $keytool, $androidJar)) {
    if (-not (Test-Path $p)) { throw "Missing tool: $p" }
}

$env:JAVA_HOME = $jdk
$env:PATH = "$jdk\bin;$env:PATH"

# ---------------- staging (ASCII path only) ----------------
$stage = Join-Path $env:TEMP 'cet4-apk-build'
if (Test-Path $stage) { Remove-Item -LiteralPath $stage -Recurse -Force }
New-Item -ItemType Directory -Path $stage | Out-Null
New-Item -ItemType Directory -Path (Join-Path $stage 'classes') | Out-Null
New-Item -ItemType Directory -Path (Join-Path $stage 'dex') | Out-Null
New-Item -ItemType Directory -Path (Join-Path $stage 'assets') | Out-Null
if (-not (Test-Path $outDir)) { New-Item -ItemType Directory -Path $outDir | Out-Null }

Write-Host '=== 1/7 stage sources (ASCII path) ===' -ForegroundColor Cyan
Copy-Item -LiteralPath (Join-Path $here 'AndroidManifest.xml') -Destination $stage
Copy-Item -LiteralPath (Join-Path $here 'res') -Destination $stage -Recurse
Copy-Item -LiteralPath (Join-Path $here 'java') -Destination $stage -Recurse

$files = @('index.html', 'app.js', 'words.js', 'manifest.json', 'sw.js',
           'favicon.png', 'icon-192.png', 'icon-512.png')
foreach ($f in $files) {
    $src = Join-Path $appRoot $f
    if (-not (Test-Path $src)) { throw "Not found: $src" }
    Copy-Item -LiteralPath $src -Destination (Join-Path $stage 'assets')
}
Write-Host ("    copied " + $files.Count + " web files")

Write-Host '=== 2/7 aapt2 compile ===' -ForegroundColor Cyan
$resZip = Join-Path $stage 'res.zip'
& $aapt2 compile --dir (Join-Path $stage 'res') -o $resZip
if ($LASTEXITCODE -ne 0) { throw 'aapt2 compile failed' }

Write-Host '=== 3/7 aapt2 link ===' -ForegroundColor Cyan
$baseApk = Join-Path $stage 'base.apk'
& $aapt2 link -o $baseApk -I $androidJar `
    --manifest (Join-Path $stage 'AndroidManifest.xml') `
    -A (Join-Path $stage 'assets') `
    --min-sdk-version 21 --target-sdk-version 34 `
    --version-code 1 --version-name '1.0' `
    $resZip
if ($LASTEXITCODE -ne 0) { throw 'aapt2 link failed' }

Write-Host '=== 4/7 javac ===' -ForegroundColor Cyan
$classes = Join-Path $stage 'classes'
$srcJava = Join-Path $stage 'java\com\cet4\memo\MainActivity.java'
& $javac -source 8 -target 8 -nowarn -encoding UTF-8 -classpath $androidJar -d $classes $srcJava
if ($LASTEXITCODE -ne 0) { throw 'javac failed' }

Write-Host '=== 5/7 d8 -> classes.dex ===' -ForegroundColor Cyan
$dexDir = Join-Path $stage 'dex'
$classFiles = Get-ChildItem -Path $classes -Filter *.class -Recurse | ForEach-Object { $_.FullName }
& $d8 --lib $androidJar --min-api 21 --output $dexDir @classFiles
if ($LASTEXITCODE -ne 0) { throw 'd8 failed' }

Write-Host '=== 6/7 package + zipalign ===' -ForegroundColor Cyan
$unsigned = Join-Path $stage 'unsigned.apk'
$py = 'C:\Users\20682\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
& $py (Join-Path $here 'add-dex.py') $baseApk (Join-Path $dexDir 'classes.dex') $unsigned
if ($LASTEXITCODE -ne 0) { throw 'adding classes.dex failed' }
$aligned = Join-Path $stage 'aligned.apk'
& $zipalign -p -f 4 $unsigned $aligned
if ($LASTEXITCODE -ne 0) { throw 'zipalign failed' }

Write-Host '=== 7/7 apksigner ===' -ForegroundColor Cyan
# 签名证书固定放在工程里，重新打包也用同一个，装到手机上才能覆盖升级
$ks = Join-Path (Split-Path -Parent $here) 'cet4.keystore'
if (-not (Test-Path $ks)) {
    & $keytool -genkeypair -v -keystore $ks -alias cet4 `
        -keyalg RSA -keysize 2048 -validity 10950 `
        -storepass cet4memo -keypass cet4memo `
        -dname 'CN=SiJiJiYi, OU=Study, O=Study, L=Beijing, ST=Beijing, C=CN'
    if ($LASTEXITCODE -ne 0) { throw 'keytool failed' }
}

$signed = Join-Path $stage 'signed.apk'
& $apksigner sign --ks $ks --ks-key-alias cet4 `
    --ks-pass pass:cet4memo --key-pass pass:cet4memo `
    --out $signed $aligned
if ($LASTEXITCODE -ne 0) { throw 'apksigner sign failed' }

& $apksigner verify --print-certs $signed | Select-Object -First 4

$finalApk = Join-Path $outDir '四级记忆.apk'
Copy-Item -LiteralPath $signed -Destination $finalApk -Force
$size = [Math]::Round((Get-Item $finalApk).Length / 1MB, 2)

Write-Host ''
Write-Host ("OK  APK built: $finalApk  ($size MB)") -ForegroundColor Green
